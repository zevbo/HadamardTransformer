__version__ = "1.0.4.post1"

from fast_hadamard_transform.fast_hadamard_transform_interface import hadamard_transform
